<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registrasi Anggota</title>

    
    <link rel="stylesheet" href="<?= base_url('assets/vendor/bootstrap/css/bootstrap.min.css') ?>">

    
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>

<body class="bg-dark">

<div class="container vh-100 d-flex justify-content-center align-items-center">
    <div class="col-lg-5 col-md-7 col-sm-10">

        <div class="card shadow">
            <div class="card-header bg-primary text-white text-center">
                <h4 class="mb-0">
                    <i class="fa fa-user"></i> Registrasi Anggota
                </h4>
            </div>

            <div class="card-body">
                <form id="form-anggota">

                    <div class="form-group">
                        <label>NIS</label>
                        <input type="text" class="form-control" name="nis">
                    </div>

                    <div class="form-group">
                        <label>Nama Siswa</label>
                        <input type="text" class="form-control" name="nm_siswa">
                    </div>

                    <div class="form-group">
                        <label>Kelas</label>
                        <input type="text" class="form-control" name="kelas">
                    </div>

                    <div class="form-group">
                        <label>Alamat</label>
                        <textarea class="form-control" name="alamat"></textarea>
                    </div>

                    <hr>
                    <small class="text-muted d-block mb-2">
                        <b>Pembuatan User Anggota</b>
                    </small>

                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" class="form-control" id="username" name="username">
                    </div>

                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" class="form-control" id="password" name="password">
                    </div>

                </form>

                <button class="btn btn-primary btn-block" id="btn-simpan">
                    <i class="fa fa-save"></i> Proses Registrasi
                </button>

                <a href="<?= site_url('login-sistem') ?>" class="btn btn-secondary btn-block mt-2">
                    <i class="fa fa-sign-in-alt"></i> Login Anggota
                </a>
            </div>
        </div>

    </div>
</div>


<script src="<?=base_url()?>assets/plugins/jquery/jquery.min.js"></script>
<script src="<?= base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>

<script>
$(document).ready(function () {

    $('#btn-simpan').click(function () {

        let formData = new FormData($('#form-anggota')[0]);

        if ($('#username').val() === '' || $('#password').val() === '') {
            alert('Username dan Password wajib diisi');
            return false;
        }

        $.ajax({
            type: 'POST',
            url: '<?= site_url('registrasi-save') ?>',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'JSON',
            success: function (res) {
                if (res.status) {
                    alert('Registrasi berhasil');
                    window.location.href = '<?= site_url('login-sistem') ?>';
                }
            }
        });

        return false;

        alert('test')
    });

});
</script>

</body>
</html>
