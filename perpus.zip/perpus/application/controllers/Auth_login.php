<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_login extends CI_Controller
{
    public function index()
    {
        if ($this->session->userdata('logged') == 1) {
            redirect('halaman-sistem');
            return;
        }

        $this->load->view('back-end/layout/login');
    }

    public function login()
    {
        $username = $this->input->post('username', TRUE);
        $password = $this->input->post('password');

        if ($username == '' || $password == '') {
            $this->session->set_flashdata('error', 'Username dan Password wajib diisi');
            redirect('login-sistem');
            return;
        }

        $user = $this->db
            ->get_where('users', ['username' => $username])
            ->row();

        if (!$user || !password_verify($password, $user->password)) {
            $this->session->set_flashdata('error', 'Username atau Password salah');
            redirect('login-sistem');
            return;
        }

        
     
        
        if (strtolower($user->role) === 'siswa') {

            $anggota = $this->db
                ->get_where('anggota', ['user_id' => $user->id])
                ->row();

            if (!$anggota) {
                $this->session->set_flashdata('error', 'Data anggota tidak ditemukan');
                redirect('login-sistem');
                return;
            }

            
            if (($anggota->status ?? 'aktif') !== 'aktif') {
                $this->session->set_flashdata('error', 'Akun Anda Non Aktif');
                redirect('login-sistem');
                return;
            }

            $this->session->set_userdata([
                'logged'      => 1,
                'role'        => 'siswa',
                'id_user'     => $user->id,
                'anggota_id'  => $anggota->id,
                'nama'        => $user->nama,
                'nis'         => $anggota->nis,
                'kelas'       => $anggota->kelas
            ]);
        }

        
        
        else {

            $this->session->set_userdata([
                'logged'  => 1,
                'role'    => 'admin',
                'id_user' => $user->id,
                'nama'    => $user->nama
            ]);
        }

        redirect('halaman-sistem');
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('login-sistem');
    }
}