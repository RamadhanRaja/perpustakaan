/*
SQLyog Enterprise v12.09 (64 bit)
MySQL - 10.4.27-MariaDB : Database - perpustakaan
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`perpustakaan` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `perpustakaan`;

/*Table structure for table `anggota` */

DROP TABLE IF EXISTS `anggota`;

CREATE TABLE `anggota` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `nis` varchar(50) DEFAULT NULL,
  `kelas` varchar(50) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `status` enum('aktif','nonaktif') DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `anggota` */

insert  into `anggota`(`id`,`user_id`,`nis`,`kelas`,`alamat`,`status`) values (9,16,'23252602','XII RPL','Cibur',NULL),(7,13,'23252601','XII RPL','cikiwul','aktif');

/*Table structure for table `buku` */

DROP TABLE IF EXISTS `buku`;

CREATE TABLE `buku` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode_buku` varchar(50) DEFAULT NULL,
  `judul` varchar(150) DEFAULT NULL,
  `pengarang` varchar(100) DEFAULT NULL,
  `penerbit` varchar(100) DEFAULT NULL,
  `tahun` year(4) DEFAULT NULL,
  `stok` int(11) DEFAULT 0,
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `buku` */

insert  into `buku`(`id`,`kode_buku`,`judul`,`pengarang`,`penerbit`,`tahun`,`stok`) values (4,'321','kelinci','aji erlangga','rama',0000,48),(5,'443','aku si anak pemberani','rositu','gogo',2018,42);

/*Table structure for table `peminjaman` */

DROP TABLE IF EXISTS `peminjaman`;

CREATE TABLE `peminjaman` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `anggota_id` int(11) DEFAULT NULL,
  `tgl_pinjam` date DEFAULT NULL,
  `tgl_kembali` date DEFAULT NULL,
  `status` enum('dipinjam','dikembalikan') DEFAULT 'dipinjam',
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `peminjaman` */

insert  into `peminjaman`(`id`,`anggota_id`,`tgl_pinjam`,`tgl_kembali`,`status`) values (33,7,'2026-02-25','2026-02-22','dikembalikan'),(32,7,'2026-02-25','2026-02-27','dikembalikan'),(31,7,'2026-02-27','2026-02-25','dikembalikan'),(30,7,'2026-02-25','2026-01-12','dikembalikan'),(29,7,'2026-02-25','2026-02-26','dikembalikan'),(28,7,'2026-02-25','2026-02-27','dikembalikan'),(27,7,'2026-02-25','2026-02-27','dikembalikan'),(26,7,'2026-02-25','2026-02-27','dikembalikan'),(25,7,'2026-02-25','2026-02-27','dikembalikan'),(24,8,'2026-02-25','2026-02-25','dikembalikan');

/*Table structure for table `peminjaman_detail` */

DROP TABLE IF EXISTS `peminjaman_detail`;

CREATE TABLE `peminjaman_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `peminjaman_id` int(11) DEFAULT NULL,
  `buku_id` int(11) DEFAULT NULL,
  `qty` int(11) DEFAULT 1,
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `peminjaman_detail` */

insert  into `peminjaman_detail`(`id`,`peminjaman_id`,`buku_id`,`qty`) values (33,33,4,1),(32,32,4,1),(31,31,4,1),(30,30,4,1),(29,29,4,1),(28,28,4,1),(27,27,5,1),(26,26,5,1),(25,25,4,1),(24,24,4,1);

/*Table structure for table `pengembalian` */

DROP TABLE IF EXISTS `pengembalian`;

CREATE TABLE `pengembalian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `peminjaman_id` int(11) DEFAULT NULL,
  `tgl_pengembalian` date DEFAULT NULL,
  `denda` int(11) DEFAULT 0,
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `pengembalian` */

insert  into `pengembalian`(`id`,`peminjaman_id`,`tgl_pengembalian`,`denda`) values (25,33,'2026-02-25',6000),(24,32,'2026-02-25',0),(23,30,'2026-02-25',88000),(22,31,'2026-02-25',0),(21,29,'2026-02-25',0),(20,28,'2026-02-25',0),(19,26,'2026-02-25',0),(18,27,'2026-02-25',0),(17,25,'2026-02-25',0),(16,24,'2026-02-25',0);

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `role` enum('admin','siswa') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Data for the table `users` */

insert  into `users`(`id`,`nama`,`username`,`password`,`role`,`created_at`) values (16,'Erlangga Prasetyo','angga','$2y$10$AHgMYk68hvNjbCTG3KM6pu1EM7J4u4qGFfRuTPm6Tz5nYtqjJWFia','siswa','2026-02-25 13:05:10'),(15,'admin','admin','$2y$10$AXplSBZEWbYjeMvutSxqMO4VXlCczKPwCFjXaRDa9a4LvJcrVWxii','admin','2026-02-25 09:24:07'),(13,'Ramadhan Raja','rama','$2y$10$rbHod7esUvPpkjhrYnerRup5WJOnLTXW/Ax8yXjf1Fu8oOZkI/lZ.','siswa','2026-02-25 13:11:15'),(11,'admin','admin','$2y$10$6fcHJBAPKLiYO/idnG560OFU.NxRM2jZ7arin9aaqRHG6AByInAMG','admin','2026-02-25 07:11:10');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
