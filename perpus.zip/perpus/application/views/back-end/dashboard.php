<div class="container-fluid">

    <!-- PAGE HEADER -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card shadow-sm border-0 bg-primary text-white">
                <div class="card-body">
                    <h3 class="mb-1">
                        <i class="fa fa-book">PERPUSTAKAAN</i>
                    </h3>
                    <p class="mb-0">
                        Selamat datang, 
                        <strong><?= $this->session->userdata('nama'); ?></strong>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- ADMIN DASHBOARD -->
    <?php if ($this->session->userdata('role') == 'admin'): ?>

    <div class="row">

        <div class="col-md-4">
            <div class="card shadow-sm border-left-primary">
                <div class="card-body text-center">
                    <i class="fa fa-users fa-3x text-primary mb-3"></i>
                    <h5>Kelola Anggota</h5>
                    <p class="text-muted">Tambah & kelola data anggota perpustakaan.</p>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow-sm border-left-success">
                <div class="card-body text-center">
                    <i class="fa fa-book fa-3x text-success mb-3"></i>
                    <h5>Kelola Buku</h5>
                    <p class="text-muted">Manajemen data buku & stok.</p>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow-sm border-left-danger">
                <div class="card-body text-center">
                    <i class="fa fa-exchange-alt fa-3x text-danger mb-3"></i>
                    <h5>Transaksi</h5>
                    <p class="text-muted">Kelola peminjaman & pengembalian.</p>
                </div>
            </div>
        </div>

    </div>

    <!-- SISWA DASHBOARD -->
    <?php else: ?>

    <div class="row">

        <div class="col-md-6">
            <div class="card shadow-sm border-left-primary">
                <div class="card-body text-center">
                    <i class="fa fa-book fa-3x text-primary mb-3"></i>
                    <h5>Peminjaman Buku</h5>
                    <p class="text-muted">Pinjam buku yang tersedia di perpustakaan.</p>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow-sm border-left-success">
                <div class="card-body text-center">
                    <i class="fa fa-undo fa-3x text-success mb-3"></i>
                    <h5>Pengembalian Buku</h5>
                    <p class="text-muted">Kembalikan buku yang sudah dipinjam.</p>
                </div>
            </div>
        </div>

    </div>

    <?php endif; ?>

</div>
